# CHANGELOG for application_test

This file is used to list changes made in each version of application_test.

## 0.1.0:

* Initial release of application_test

- - - 
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
